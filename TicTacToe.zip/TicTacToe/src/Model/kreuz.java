package Model;

public class kreuz implements zeichen{

	private char Zeichen = 'X';

	@Override
	public void zeichnen() {
		System.out.println(Zeichen);
	}
	public char getZeichen() {
		return Zeichen;
	}
}
