package Model;

public class lehr implements zeichen{

	private char Zeichen = '_';

	@Override
	public void zeichnen() {
		System.out.println(Zeichen);
		
	}

	public char getZeichen() {
		return Zeichen;
	}
}
