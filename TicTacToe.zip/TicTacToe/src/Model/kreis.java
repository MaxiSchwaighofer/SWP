package Model;

public class kreis implements zeichen{

	private char Zeichen = 'O';

	@Override
	public void zeichnen() {
		System.out.println(Zeichen);
		
	}
	public char getZeichen() {
		return Zeichen;
	}
}
