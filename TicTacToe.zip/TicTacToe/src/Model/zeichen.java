package Model;

public interface zeichen {

	public void zeichnen();
	public char getZeichen();
}
