package View;

import java.util.Scanner;

import Controller.Command;
import Controller.zeichenFactory;
import Model.zeichen;

public class ZeichenTest {

	public static char state ='o';
	static char [][]r = new char[3][3];
	static Scanner sc = new Scanner(System.in); 


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		zeichenFactory zf= zeichenFactory.getInstance();
		zeichen kreis = zf.getZeichen("kreis");
		zeichen kreuz = zf.getZeichen("kreuz");
		zeichen lehr = zf.getZeichen("lehr");
		
		Command c = new Command();
		
	
		
		r = Initialisieren(r);
		Zeichne(r);
		boolean nichtGewonnen = true;

		while(nichtGewonnen) {
			System.out.print(state);
			System.out.println(" ist an der Reihe");
			System.out.println("Wo wollen Sie setzen[ypos]");
		    String xpos = sc.nextLine();  

		    int x = Integer.parseInt(xpos);
			System.out.println("Wo wollen Sie setzen[xpos]");
			String ypos = sc.nextLine();
			
			int y = Integer.parseInt(ypos);
			
			
		    String position = x + ";"+y;
			c.doingMove(position);

			SpielzugG�ltig(x, y);			
		    nichtGewonnen=HatGewonnen(r);

		}
		
		
		if(HatGewonnen(r)) System.out.println(state);
		
	}
	public static char[][] setPos(int x,int y) {		
		zeichenFactory zf = zeichenFactory.getInstance();
		
		r[x][y] = state;
		Zeichne(r);
		
		String commmand =  x + ";" + y;
		changeState();
		Command cmd = new Command();
		cmd.doingMove(commmand);
		checkUndo();
		return r;
	}
	public static void checkUndo() {
		System.out.println("Wollen Sie den Zug R�ckg�ngig machen?[y/n]");
		String undo = sc.nextLine();
		if(undo.equals("y")) {
			Command cmd = new Command();
			cmd.Undo();
		}
		
	}
	
	public static void changeState() {
		
		if(state == 'x') {
			state =  'o';
		}else {
			state =  'x';
		}
	}
	public static char[][] Initialisieren(char [][] z) {
		char [][]r = new char[3][3];
		zeichenFactory zf = zeichenFactory.getInstance();
		zeichen lehr = zf.getZeichen("lehr");
		for(int i = 0; i<=2; i++) {
			for (int j = 0; j<=2; j++) {
				r[i][j]= lehr.getZeichen();
			}
		}
		return r;
	}
	public static void SpielzugG�ltig(int xpos, int ypos) {
		if(r[xpos][ypos] == '_') {
			setPos(xpos, ypos);
		}else{
			System.out.println("belegtes Feld ausgew�hlt!");
			Zeichne(r);
			}
		
	}
	public static void undoMove(int xpos,int ypos) {
		r[xpos][ypos] = '_';
		Zeichne(r);
	}
	
	public static boolean HatGewonnen(char[][] feld) {
		boolean spielgewonnen = true;
		
		if((feld[0][0] == feld[0][1] && feld[0][0] == feld[0][2] && feld[0][0] != '_') ||
				(feld[1][0] == feld[1][1] && feld[1][0] == feld[1][2] && feld[1][0] != '_')||
				(feld[2][0] == feld[2][1] && feld[2][0] == feld[2][2] && feld[2][0] != '_')
				)
		{
			spielgewonnen = false;
		}
		if((feld[0][0] == feld[1][0] && feld[0][0] == feld[2][0] && feld[0][0] != '_') ||
				(feld[0][1] == feld[1][1] && feld[0][1] == feld[2][1] && feld[0][1] != '_')||
				(feld[0][2] == feld[1][2] && feld[0][2] == feld[2][2] && feld[0][2] != '_')
				) {
			spielgewonnen = false;
		}
		
	if(feld[0][0] == feld[1][1] && feld[0][0] == feld[2][2] && feld[0][0] != '_') {
		spielgewonnen = false;
	}
	if(feld[0][2] == feld[1][1] && feld[0][2] == feld[2][0] && feld[0][2] != '_') {
		spielgewonnen = false;
	}
	
	
		return spielgewonnen;
	}
	
	public static void Zeichne(char [][] z) {
		System.out.println("x 0 1 2y");
		
		for(int i = 0; i <=2; i++) {
			System.out.print("_");

			for (int j = 0; j<=2; j++) {
				
				System.out.print(z[i][j]);
				if(j<2) {
				System.out.print("|");
				}
			}
			
			System.out.println(i);

			if(i<2) {
				System.out.print("_");

				System.out.println("- - -");
				}
			
			
		}
	}
}
