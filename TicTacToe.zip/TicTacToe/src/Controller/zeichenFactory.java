package Controller;

import Model.kreis;
import Model.kreuz;
import Model.lehr;
import Model.zeichen;

public class zeichenFactory {
	private static zeichenFactory instance = new zeichenFactory();
	
	private zeichenFactory() {}
	public static zeichenFactory getInstance() {
		return instance;
	}
	   public zeichen getZeichen(String zeichen){
	      if(zeichen == null){
	         return null;
	      }		
	      if(zeichen.equalsIgnoreCase("kreis")){
	         return new kreis();
	         
	      } else if(zeichen.equalsIgnoreCase("kreuz")){
	         return new kreuz();
	         
	      }else if(zeichen.equalsIgnoreCase("lehr")) {
	    	  return new lehr();
	      }
	      
	      return null;
	   }		
}

