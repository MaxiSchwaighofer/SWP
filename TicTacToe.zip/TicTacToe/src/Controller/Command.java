package Controller;

import java.util.ArrayList;


import View.ZeichenTest;

public class Command {

	

	 static ArrayList<String> Undoliste = new ArrayList<String>();
	 static ArrayList<String> RedoList = new ArrayList<>();
	 ZeichenTest zt = new ZeichenTest();
	
	public void doingMove(String saveMove) {
		Undoliste.add(saveMove);
	}
	public void Undo() {
		
	int length = Undoliste.size() - 1;
	String getElement = Undoliste.get(length);
	String[] splitStr = Undoliste.get(length).split(";");
	int xpos = Integer.valueOf(splitStr[0]);
	int ypos = Integer.valueOf(splitStr[1]);
	ZeichenTest.undoMove(xpos, ypos);
	ZeichenTest.changeState();	
	Undoliste.remove(length);
	
	RedoList.add(getElement);
	}
	public void Redo() {
	int length = RedoList.size() - 1;
	String[] splitStr = RedoList.get(length).split(";");
	int x = Integer.valueOf(splitStr[0]);
	int y = Integer.valueOf(splitStr[1]);
	ZeichenTest.setPos(x, y);
	RedoList.remove(length);
	}

}
