import AbstrakteKlassen.Benachrichtiger;

public class Lehrer extends Benachrichtiger{

	@Override
	public void Weiterleiten(int Messwert) {
		if(Messwert >30) {
		System.out.println("Schnautze es passt so!");
		}else {
			System.out.println("Mach die Heitzung aus!");
		}
	}
}
