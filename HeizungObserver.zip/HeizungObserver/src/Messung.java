


public class Messung {

	Heizung hei = new Heizung();
	int temp = (int) (Math.random()*100);
	
	public void setMesswert() {
		hei.neueTemp(temp);
	}

	
}
