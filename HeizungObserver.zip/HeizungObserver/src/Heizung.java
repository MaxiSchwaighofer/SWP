import java.util.ArrayList;

import AbstrakteKlassen.Benachrichtiger;

public class Heizung {

	ArrayList<Benachrichtiger> e = new ArrayList<>();
	Sch�ler s = new Sch�ler();
	Lehrer l = new Lehrer();
	
	
	public void neueTemp(int Messung) {
		e.add(s);
		e.add(l);
		
		e.get(0).Weiterleiten(Messung);
		e.get(1).Weiterleiten(Messung);
	}
}
