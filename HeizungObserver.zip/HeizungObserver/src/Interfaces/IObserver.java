package Interfaces;

public interface IObserver {
	public void Weiterleiten(int Messwert);
}
