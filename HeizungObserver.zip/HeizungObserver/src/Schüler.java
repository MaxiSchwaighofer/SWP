import AbstrakteKlassen.Benachrichtiger;

public class Sch�ler extends Benachrichtiger{
	
	@Override
	public void Weiterleiten(int Messwert) {
		System.out.println("MiR IS ZHOAS");
	}
}
