
public class test {
	public static void main(String[] args) {
		Messung m  =new Messung();
		m.setMesswert();
	}
}
