package AbstrakteKlassen;

public abstract class Benachrichtiger {

	public void Weiterleiten (int Messwert) {
		System.out.println(Messwert);
	}
}
