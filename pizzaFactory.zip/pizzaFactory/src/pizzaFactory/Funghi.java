package pizzaFactory;

public class Funghi implements Pizza{

	@Override
	public void backen() {
		System.out.println("A Funghi sollsch backen ok!");
	}
}
