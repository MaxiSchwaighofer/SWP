package pizzaFactory;

public class PizzaFactory {

	public Pizza getPizza(String pizzaTyp) {
	      if(pizzaTyp.equalsIgnoreCase("Margherita")){
	         return new Margherita();
	         
	      } else if(pizzaTyp.equalsIgnoreCase("Diavolo")){
	         return new Diavolo();
	         
	      } else if(pizzaTyp.equalsIgnoreCase("Funghi")){
	         return new Funghi();
	      }
	      
	      return null;
	}
}
