package pizzaFactory;

public class Margherita implements Pizza{

	@Override
	public void backen(){
		System.out.println("A Margherita sollsch machen ok!");
	}
}
