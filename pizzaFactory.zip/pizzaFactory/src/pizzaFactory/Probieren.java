package pizzaFactory;

public class Probieren {

	public static void main(String[] args) {

		PizzaFactory pizzaF = new PizzaFactory();
		
		Pizza p1 = pizzaF.getPizza("Margherita");
		p1.backen();
		Pizza p2 = pizzaF.getPizza("Diavolo");
		p2.backen();
		Pizza p3 = pizzaF.getPizza("Funghi");
		p3.backen();
	}

}
