package pizzaFactory;

public interface Pizza {
	void backen();
}
