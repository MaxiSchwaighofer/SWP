package pizzaFactory;

public class Diavolo implements Pizza{

	@Override
	public void backen() {
		System.out.println("A Diavolo sollsch machen ok!");
	}
}
